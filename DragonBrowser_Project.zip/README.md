# DRAGON BROWSER by MAHIR
Kiwi-style Android browser (WebView) with Desktop site mode + DRAGON MASTER mic/call booster built in.
Build: upload this project to GitHub -> Actions -> Build APK -> download artifact DragonBrowser-APK.
