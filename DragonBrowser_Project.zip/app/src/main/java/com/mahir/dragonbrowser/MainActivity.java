package com.mahir.dragonbrowser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {

    static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/124.0.0.0 Safari/537.36";
    static final String HOME_URL = "https://dragon.home/";
    static final int ACCENT = 0xFFFF5A1F;
    static final int BAR = 0xFF14100F;
    static final int FIELD = 0xFF2A2321;

    static final Set<String> BOOST_ORIGINS = new HashSet<>(Arrays.asList(
            "https://facebook.com", "https://*.facebook.com",
            "https://messenger.com", "https://*.messenger.com",
            "https://whatsapp.com", "https://*.whatsapp.com",
            "https://telegram.org", "https://*.telegram.org",
            "https://instagram.com", "https://*.instagram.com"));

    static class Tab {
        WebView web;
        String title = "New tab";
        ScriptHandler handler;
    }

    final List<Tab> tabs = new ArrayList<>();
    int current = -1;

    SharedPreferences prefs;
    boolean desktop;
    boolean docStart;
    String defaultUa;
    String injectorJs = "";

    FrameLayout root;
    FrameLayout holder;
    EditText urlBar;
    ProgressBar progress;
    TextView desktopBtn;
    TextView tabBtn;

    ValueCallback<Uri[]> filePathCallback;
    View customView;
    WebChromeClient.CustomViewCallback customCallback;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("dragon", MODE_PRIVATE);
        desktop = prefs.getBoolean("desktop", false);
        defaultUa = WebSettings.getDefaultUserAgent(this);
        docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        injectorJs = readAsset("injector.js");

        getWindow().setStatusBarColor(BAR);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        buildUi();
        askRuntimePermissions();

        String start = null;
        Intent in = getIntent();
        if (in != null && Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            start = in.getData().toString();
        }
        newTab(start);
    }

    @Override
    protected void onNewIntent(Intent in) {
        super.onNewIntent(in);
        if (in != null && Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            newTab(in.getData().toString());
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // keep calls alive in background: do not pause timers on purpose
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) {
            try { t.web.destroy(); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
            return;
        }
        Tab t = tab();
        if (t != null && t.web.canGoBack()) {
            t.web.goBack();
        } else if (tabs.size() > 1) {
            closeTab(current);
        } else {
            super.onBackPressed();
        }
    }

    // ------------------------------------------------------------------ UI

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    TextView barButton(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(19);
        t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(44)));
        t.setOnClickListener(l);
        return t;
    }

    void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(4), dp(2), dp(4), dp(2));

        bar.addView(barButton("◀", v -> {
            Tab t = tab();
            if (t != null && t.web.canGoBack()) t.web.goBack();
        }));

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setTextColor(Color.WHITE);
        urlBar.setHintTextColor(0xFF9A8F8A);
        urlBar.setHint("সার্চ করুন বা লিংক দিন");
        urlBar.setTextSize(14);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(FIELD);
        bg.setCornerRadius(dp(20));
        urlBar.setBackground(bg);
        urlBar.setPadding(dp(14), 0, dp(14), 0);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        ulp.setMargins(dp(2), 0, dp(2), 0);
        urlBar.setLayoutParams(ulp);
        urlBar.setOnEditorActionListener((v, actionId, ev) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                hideKeyboard();
                return true;
            }
            return false;
        });
        bar.addView(urlBar);

        desktopBtn = barButton("🖥", v -> setDesktop(!desktop));
        bar.addView(desktopBtn);

        bar.addView(barButton("⟳", v -> {
            Tab t = tab();
            if (t != null) t.web.reload();
        }));

        tabBtn = barButton("1", v -> showTabs());
        GradientDrawable box = new GradientDrawable();
        box.setStroke(dp(2), Color.WHITE);
        box.setCornerRadius(dp(6));
        tabBtn.setBackground(box);
        tabBtn.setTextSize(13);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(dp(30), dp(30));
        tlp.setMargins(dp(6), 0, dp(6), 0);
        tabBtn.setLayoutParams(tlp);
        bar.addView(tabBtn);

        bar.addView(barButton("⋮", v -> showMenu()));
        col.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.getProgressDrawable().setColorFilter(ACCENT, android.graphics.PorterDuff.Mode.SRC_IN);
        progress.setVisibility(View.GONE);
        col.addView(progress, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        holder = new FrameLayout(this);
        col.addView(holder, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        refreshDesktopButton();
    }

    void refreshDesktopButton() {
        desktopBtn.setAlpha(desktop ? 1f : 0.35f);
        desktopBtn.setBackgroundColor(desktop ? 0x55FF5A1F : Color.TRANSPARENT);
    }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        urlBar.clearFocus();
    }

    // ------------------------------------------------------------------ tabs

    Tab tab() {
        return (current >= 0 && current < tabs.size()) ? tabs.get(current) : null;
    }

    void newTab(String url) {
        Tab t = new Tab();
        t.web = createWebView(t);
        tabs.add(t);
        selectTab(tabs.size() - 1);
        if (url == null || url.isEmpty()) loadHome(t.web);
        else t.web.loadUrl(url);
    }

    void selectTab(int i) {
        current = i;
        holder.removeAllViews();
        Tab t = tabs.get(i);
        holder.addView(t.web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        String u = t.web.getUrl();
        urlBar.setText(shownUrl(u));
        progress.setVisibility(View.GONE);
        tabBtn.setText(String.valueOf(tabs.size()));
    }

    void closeTab(int i) {
        Tab t = tabs.remove(i);
        try {
            if (t.handler != null) t.handler.remove();
        } catch (Exception ignored) { }
        holder.removeView(t.web);
        t.web.destroy();
        if (tabs.isEmpty()) {
            newTab(null);
            return;
        }
        selectTab(Math.min(i, tabs.size() - 1));
    }

    void showTabs() {
        String[] names = new String[tabs.size()];
        for (int i = 0; i < tabs.size(); i++) {
            names[i] = (i == current ? "● " : "○ ") + tabs.get(i).title;
        }
        new AlertDialog.Builder(this)
                .setTitle("ট্যাব (" + tabs.size() + ")")
                .setItems(names, (d, which) -> selectTab(which))
                .setPositiveButton("+ নতুন ট্যাব", (d, w) -> newTab(null))
                .setNegativeButton("এই ট্যাব বন্ধ", (d, w) -> closeTab(current))
                .show();
    }

    // ------------------------------------------------------------------ webview

    WebView createWebView(final Tab t) {
        final WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        applyMode(w);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);

        installScript(t, w);

        w.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                String name = URLUtil.guessFileName(url, cd, mime);
                r.setMimeType(mime);
                r.addRequestHeader("User-Agent", ua);
                String ck = CookieManager.getInstance().getCookie(url);
                if (ck != null) r.addRequestHeader("Cookie", ck);
                r.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "ডাউনলোড শুরু: " + name, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "ডাউনলোড করা গেল না", Toast.LENGTH_SHORT).show();
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http://") || u.startsWith("https://")
                        || u.startsWith("about:") || u.startsWith("data:")
                        || u.startsWith("blob:")) {
                    return false;
                }
                try {
                    Intent i = u.startsWith("intent:")
                            ? Intent.parseUri(u, Intent.URI_INTENT_SCHEME)
                            : new Intent(Intent.ACTION_VIEW, Uri.parse(u));
                    startActivity(i);
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                if (!docStart && isBoostHost(url)) {
                    v.evaluateJavascript(buildScript(), null);
                }
                if (tab() != null && tab().web == v) {
                    urlBar.setText(shownUrl(url));
                    progress.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (isBoostHost(url)) {
                    v.evaluateJavascript(configMessage(), null);
                }
                if (tab() != null && tab().web == v) {
                    progress.setVisibility(View.GONE);
                    if (!urlBar.hasFocus()) urlBar.setText(shownUrl(url));
                }
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (tab() != null && tab().web == v) {
                    progress.setProgress(p);
                    progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                t.title = (title == null || title.isEmpty()) ? "New tab" : title;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), 77);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCallback = cb;
                root.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }
        });
        return w;
    }

    void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == 77 && filePathCallback != null) {
            filePathCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(res, data));
            filePathCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    // ------------------------------------------------------------------ desktop mode

    void applyMode(WebView w) {
        WebSettings s = w.getSettings();
        if (desktop) {
            s.setUserAgentString(DESKTOP_UA);
            s.setLoadWithOverviewMode(true);
        } else {
            s.setUserAgentString(defaultUa);
            s.setLoadWithOverviewMode(false);
        }
    }

    void setDesktop(boolean on) {
        desktop = on;
        prefs.edit().putBoolean("desktop", on).apply();
        for (Tab t : tabs) applyMode(t.web);
        refreshDesktopButton();
        Tab t = tab();
        if (t != null) {
            String u = t.web.getUrl();
            if (u != null && !u.startsWith(HOME_URL)) t.web.reload();
        }
        Toast.makeText(this, on ? "ডেস্কটপ সাইড: চালু" : "ডেস্কটপ সাইড: বন্ধ",
                Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ navigation

    void go(String input) {
        Tab t = tab();
        if (t == null) return;
        t.web.loadUrl(resolve(input));
    }

    static String resolve(String in) {
        String s = in.trim();
        if (s.isEmpty()) return HOME_URL;
        if (s.startsWith("http://") || s.startsWith("https://")
                || s.startsWith("file://") || s.startsWith("about:")) return s;
        if (!s.contains(" ") && s.contains(".")) return "https://" + s;
        try {
            return "https://www.google.com/search?q=" + URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return "https://www.google.com";
        }
    }

    static String shownUrl(String u) {
        if (u == null || u.startsWith(HOME_URL) || u.equals("about:blank")) return "";
        return u;
    }

    void loadHome(WebView w) {
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{margin:0;background:#14100f;color:#fff;font-family:sans-serif;text-align:center}"
                + "h1{margin:48px 0 4px;color:#ff5a1f;font-size:30px}p{color:#9a8f8a;margin:0 0 22px}"
                + "form{margin:0 18px 26px}input{width:100%;box-sizing:border-box;padding:14px 18px;"
                + "border-radius:26px;border:0;background:#2a2321;color:#fff;font-size:16px}"
                + ".g{display:flex;flex-wrap:wrap;justify-content:center;padding:0 10px}"
                + ".g a{width:84px;margin:8px;padding:14px 0;border-radius:16px;background:#2a2321;"
                + "color:#fff;text-decoration:none;font-size:13px}.g b{display:block;font-size:26px;margin-bottom:4px}"
                + "</style></head><body><h1>DRAGON BROWSER</h1><p>by MAHIR</p>"
                + "<form action='https://www.google.com/search'><input name='q' placeholder='Search Google'></form>"
                + "<div class='g'>"
                + "<a href='https://www.messenger.com'><b>💬</b>Messenger</a>"
                + "<a href='https://web.whatsapp.com'><b>🟢</b>WhatsApp</a>"
                + "<a href='https://web.telegram.org'><b>✈️</b>Telegram</a>"
                + "<a href='https://www.instagram.com'><b>📷</b>Instagram</a>"
                + "<a href='https://www.facebook.com'><b>📘</b>Facebook</a>"
                + "<a href='https://www.youtube.com'><b>▶️</b>YouTube</a>"
                + "</div></body></html>";
        w.loadDataWithBaseURL(HOME_URL, html, "text/html", "UTF-8", HOME_URL);
    }

    // ------------------------------------------------------------------ menu

    void showMenu() {
        final String[] items = {
                "নতুন ট্যাব",
                (desktop ? "☑ " : "☐ ") + "ডেস্কটপ সাইড",
                "ড্রাগন বুস্টার (মাইক/কল)",
                "হোম পেজ",
                "লিংক কপি",
                "শেয়ার",
                "কুকি ও ডেটা মুছুন",
                "বের হন"
        };
        new AlertDialog.Builder(this)
                .setItems(items, (d, which) -> {
                    Tab t = tab();
                    switch (which) {
                        case 0: newTab(null); break;
                        case 1: setDesktop(!desktop); break;
                        case 2: showBooster(); break;
                        case 3: if (t != null) loadHome(t.web); break;
                        case 4:
                            if (t != null && t.web.getUrl() != null) {
                                ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE))
                                        .setPrimaryClip(ClipData.newPlainText("url", t.web.getUrl()));
                                Toast.makeText(this, "কপি হয়েছে", Toast.LENGTH_SHORT).show();
                            }
                            break;
                        case 5:
                            if (t != null && t.web.getUrl() != null) {
                                Intent i = new Intent(Intent.ACTION_SEND);
                                i.setType("text/plain");
                                i.putExtra(Intent.EXTRA_TEXT, t.web.getUrl());
                                startActivity(Intent.createChooser(i, "শেয়ার"));
                            }
                            break;
                        case 6:
                            CookieManager.getInstance().removeAllCookies(null);
                            for (Tab x : tabs) {
                                x.web.clearCache(true);
                                x.web.clearHistory();
                            }
                            android.webkit.WebStorage.getInstance().deleteAllData();
                            Toast.makeText(this, "মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show();
                            break;
                        case 7: finishAffinity(); break;
                        default: break;
                    }
                })
                .show();
    }

    // ------------------------------------------------------------------ DRAGON booster

    static boolean isBoostHost(String url) {
        if (url == null) return false;
        String h;
        try {
            h = Uri.parse(url).getHost();
        } catch (Exception e) {
            return false;
        }
        if (h == null) return false;
        String[] roots = {"facebook.com", "messenger.com", "whatsapp.com", "telegram.org", "instagram.com"};
        for (String r : roots) {
            if (h.equals(r) || h.endsWith("." + r)) return true;
        }
        return false;
    }

    String cfgJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("enabled", prefs.getBoolean("boost", true));
            o.put("gainDb", 84);
            o.put("thresholdDb", -60);
            o.put("knee", 40);
            o.put("ratio", 20);
            o.put("attack", 0.0001);
            o.put("release", 0.03);
            o.put("lowShelfDb", 14);
            o.put("presenceDb", 20);
            o.put("highShelfDb", 16);
            o.put("limiterDb", -0.1);
            o.put("drive", 1.8);
            o.put("loudness", 20.0);
            o.put("maxBoost", 5000);
            o.put("sustain", true);
            o.put("sustainTargetDb", -2);
            o.put("sustainMaxGain", 64);
            o.put("forceRawMic", true);
            o.put("punch", 8);
            o.put("listenGain", prefs.getInt("call", 1));
            o.put("listenClarity", 7);
            o.put("listenBass", 4);
            o.put("listenPunch", 5);
            o.put("micBoost", prefs.getInt("mic", 4));
            o.put("roar", prefs.getInt("roar", 6));
            return o.toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    String configMessage() {
        return "window.postMessage({type:'MIC_MAXIMIZER_CONFIG',payload:" + cfgJson() + "},'*');";
    }

    String buildScript() {
        return injectorJs + "\n;" + configMessage();
    }

    void installScript(Tab t, WebView w) {
        if (!docStart) return;
        try {
            if (t.handler != null) t.handler.remove();
            t.handler = WebViewCompat.addDocumentStartJavaScript(w, buildScript(), BOOST_ORIGINS);
        } catch (Exception ignored) { }
    }

    void applyBoostToAll() {
        for (Tab t : tabs) {
            installScript(t, t.web);
            if (isBoostHost(t.web.getUrl())) t.web.evaluateJavascript(configMessage(), null);
        }
    }

    void slider(LinearLayout box, final String label, final int min, final int max,
                int value, final IntConsumer onSave) {
        final TextView tv = new TextView(this);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(14);
        tv.setPadding(0, dp(14), 0, 0);
        tv.setText(label + ": " + value);
        box.addView(tv);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(value - min);
        sb.getProgressDrawable().setColorFilter(ACCENT, android.graphics.PorterDuff.Mode.SRC_IN);
        sb.getThumb().setColorFilter(ACCENT, android.graphics.PorterDuff.Mode.SRC_IN);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                tv.setText(label + ": " + (p + min));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) { }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                onSave.accept(s.getProgress() + min);
                applyBoostToAll();
            }
        });
        box.addView(sb);
    }

    void showBooster() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(10), dp(22), dp(6));
        box.setBackgroundColor(BAR);

        Switch sw = new Switch(this);
        sw.setText("বুস্টার চালু");
        sw.setTextColor(Color.WHITE);
        sw.setChecked(prefs.getBoolean("boost", true));
        sw.setOnCheckedChangeListener((v, on) -> {
            prefs.edit().putBoolean("boost", on).apply();
            applyBoostToAll();
        });
        box.addView(sw);

        slider(box, "Mic gain", 1, 1000, prefs.getInt("mic", 4),
                v -> prefs.edit().putInt("mic", v).apply());
        slider(box, "Call volume", 1, 1000, prefs.getInt("call", 1),
                v -> prefs.edit().putInt("call", v).apply());
        slider(box, "Dragon Roar", 0, 10, prefs.getInt("roar", 6),
                v -> prefs.edit().putInt("roar", v).apply());

        TextView hint = new TextView(this);
        hint.setTextColor(0xFF9A8F8A);
        hint.setTextSize(12);
        hint.setPadding(0, dp(14), 0, 0);
        hint.setText("Messenger / WhatsApp / Telegram / Instagram / Facebook এ কাজ করবে। "
                + "পরিবর্তনের পর পেজ রিলোড করে কল দিন। আওয়াজ ফাটলে মান কমান।");
        box.addView(hint);

        new AlertDialog.Builder(this)
                .setTitle("DRAGON MASTER বুস্টার")
                .setView(box)
                .setPositiveButton("ঠিক আছে", null)
                .setNeutralButton("রিসেট", (d, w) -> {
                    prefs.edit().putInt("mic", 4).putInt("call", 1).putInt("roar", 6)
                            .putBoolean("boost", true).apply();
                    applyBoostToAll();
                })
                .show();
    }

    // ------------------------------------------------------------------ misc

    void askRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{
                    Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA}, 5);
        }
    }

    String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
